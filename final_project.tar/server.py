from machinetranslation.translator import englishToFrench, frenchToEnglish
from flask import Flask, render_template, request

app = Flask("Web Translator")

@app.route("/englishToFrench")
def translateEnglishToFrench():
    englishText = request.args.get('textToTranslate')
    frenchText = englishToFrench(englishText)
    return frenchText

@app.route("/frenchToEnglish")
def translateFrenchToEnglish():
    frenchText = request.args.get('textToTranslate')
    englishText = frenchToEnglish(frenchText)
    return englishText

@app.route("/")
def renderIndexPage():
    return render_template('index.html')

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
